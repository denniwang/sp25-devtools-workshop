package view;

/**
 * Interface to represent the view of the game.
 */
public interface ThreeTrioView {

}
