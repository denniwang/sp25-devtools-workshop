package model;

/**
 * Represents an attack value in the game of ThreeTrio. Attack values are from 1 to A where
 * A represents 10.
 * In the game of ThreeTrio, a playable card will have four of these attack values.
 */
public enum Attack {
  ONE(1), TWO(2), THREE(3), FOUR(4), FIVE(5), SIX(6), SEVEN(7), EIGHT(8), NINE(9), A(10);

  private final int value;

  Attack(int value) {
    this.value = value;
  }

  /**
   * Returns the value of this attack.
   */
  public int getValue() {
    return this.value;
  }


}
