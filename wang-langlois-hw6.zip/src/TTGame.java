import java.io.FileNotFoundException;

import controller.SimpleController;
import model.ReadonlyThreeTrioModel;
import model.ThreeTrioGame;
import model.ThreeTrioModel;
import view.GameView;
import view.GuiGameView;
import view.ThreeTrioGuiView;
import view.ThreeTrioView;

/**
 * Main class adopted from Red7 to run the game with the GUI.
 * Makes testing so much easier.
 */
public class TTGame {
  /**
   * Main method to run the game.
   *
   * @param args command line arguments
   * @throws FileNotFoundException if the file is not found
   */
  public static void main(String[] args) throws FileNotFoundException {
    ThreeTrioModel ttGame = new ThreeTrioGame("./board2.config", "./deck.config");
    ThreeTrioGuiView view = new GuiGameView((ReadonlyThreeTrioModel) ttGame);
    ThreeTrioView view2 = new GameView((ReadonlyThreeTrioModel) ttGame);
    SimpleController controller = new SimpleController((ThreeTrioGame) ttGame, view);
    controller.start();
    //System.out.println(controller.toString());
    //controller.playToBoard(1,0,0);
  }
}