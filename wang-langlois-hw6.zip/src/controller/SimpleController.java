package controller;

import java.io.FileNotFoundException;

import model.ThreeTrioGame;
import view.ThreeTrioGuiFeatures;
import view.ThreeTrioGuiView;

/**
 * The controller for the ThreeTrio game. Extends features to listen for in the GUI.
 */
public class SimpleController implements ThreeTrioGuiFeatures {
  private final ThreeTrioGuiView view;
  private final ThreeTrioGame model;
  private int selectedCardIdx;
  private int[] selectedBoardLocation;

  /**
   * Constructs a SimpleController with a given model and view.
   *
   * @param model model to be interacted with and rendered
   * @param view  view to render the model with and listen for user input
   */
  public SimpleController(ThreeTrioGame model, ThreeTrioGuiView view) {
    this.model = model;
    this.view = view;
    this.view.addFeaturesListener(this);
    this.selectedBoardLocation = new int[2];
    this.selectedCardIdx = -1;
  }


  /**
   * Selects a card from the player's hand in the model.
   * May come in handu if for future gui card selection implementation.
   *
   * @param cardIdx the index of the card to be selected.
   */
  public void selectCard(int cardIdx) {
    if (this.model.getTurn()) {
      if (this.selectedCardIdx == -1) {
        this.selectedCardIdx = cardIdx;
        this.view.selectP1Card(cardIdx);
      }
    } else {
      this.selectedBoardLocation[0] = cardIdx;
      this.view.selectP2Card(cardIdx);
    }
  }

  /**
   * Starts the game by creating a deck and board and displaying the view.
   */
  public void start() {
    try {
      this.model.startGame(model.createDeck(), model.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    this.view.display(true);
  }

  @Override
  public void playToBoard(int row, int col, int cardIdx) {
    this.model.playToBoard(row, col, cardIdx);
    this.view.refresh();
  }

  @Override
  public String toString() {
    return this.view.toString();
  }

  @Override
  public void quit() {
    // model does not have complete quit functions yet, will be implemented soon
    System.exit(0);
  }
}
