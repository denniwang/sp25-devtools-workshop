package view;

import java.awt.Dimension;

import javax.swing.JFrame;

import model.ReadonlyThreeTrioModel;


/**
 * Represents the GUI view of the game.
 * Renders a model of a ThreeTrio game in a JFrame.
 * To use, just pass in a readOnly TT model and it should render correctly!
 */
public class GuiGameView extends JFrame implements ThreeTrioGuiView {
  private final ThreeTrioPanel panel;

  /**
   * Constructs a GuiGameView to render a given model.
   *
   * @param model model to be rendered
   */
  public GuiGameView(ReadonlyThreeTrioModel model) {
    super("Current player: " + (model.getTurn() ? "Player 1, RED" : "Player 2, BLUE"));
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setPreferredSize(new Dimension(800, 600));
    this.panel = new ThreeTrioPanel(model);
    this.add(panel);
    this.pack();
  }

  @Override
  public void addFeaturesListener(ThreeTrioGuiFeatures features) {
    this.panel.addFeaturesListener(features);
  }

  @Override
  public void display(boolean show) {
    this.setVisible(show);
  }

  /**
   * Refreshes the view to reflect changes in the model.
   */
  public void refresh() {
    this.panel.repaint();
    super.repaint();
  }


  @Override
  public void invalidPlay() {
    // could be implemented in the future to show an invalid move
  }

  @Override
  public void selectP1Card(int cardIdx) {
    this.panel.playerOneHandClicked(cardIdx);
  }

  @Override
  public void selectP2Card(int cardIdx) {
    this.panel.playerTwoHandClicked(cardIdx);
  }
}
