package model;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.List;

import view.GameView;

import static org.junit.Assert.assertEquals;

/**
 * Class to test the model of the game.
 */
public class ModelTests {
  private ThreeTrioGame game;
  private List<ThreeTrioCard> deck;
  private ThreeTrioCard[][] board;

  @Before
  public void setup() throws FileNotFoundException {
    game = new ThreeTrioGame("board.config", "deck.config");
    this.deck = game.createDeck();
    this.board = game.createBoard();
    game.setBoard(this.board);
    game.setDeck(this.deck);
  }

  @Test
  public void testCountPossibleFlips() {
    ThreeTrioGame game = new ThreeTrioGame("board2.config", "deck.config");
    GameView view = new GameView(game);
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(1, 1, 0);
    game.playToBoard(0, 1, 0);

    System.out.println("Card we are going to play " + game.getPlayerOneHand().get(0).toString());
    Assert.assertEquals(2, game.countPossibleFlips(0, 2, game.getPlayerOneHand().get(0)));
  }

  @Test
  public void quickStart() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(0, 0, 0);
    game.playToBoard(0, 1, 0);
    // Continue playing the game however you like
    Assert.assertFalse(game.isGameOver());
  }


  /**
   * Testing that start game throws IAE if deck is null.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameNullDeck() {
    game.startGame(null, this.board);
  }

  /**
   * Testing that start game throws IAE if board is null.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameNullBoard() {
    game.startGame(this.deck, null);
  }

  /**
   * Testing that start game throws IAE if deck is too short.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameSmallDeck() {
    game.startGame(this.deck.subList(0, 1), this.board);
  }

  /**
   * Testing that start game throws IAE if board is invalid.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testStartGameInvalidBoard() {
    ThreeTrioCard[][] board = new ThreeTrioCard[1][2];
    board[0][0] = new PlayingCard();
    board[0][1] = new PlayingCard();
    game.startGame(this.deck, board);
  }

  /**
   * Testing that start game throws ISE if game is already started.
   */
  @Test(expected = IllegalStateException.class)
  public void testStartGameAlreadyStarted() {
    game.startGame(this.deck, this.board);
    game.startGame(this.deck, this.board);
  }

  /**
   * Testing that game throws ISE if trying to deal cards after game has started.
   */
  @Test(expected = IllegalStateException.class)
  public void testDealCardsAlreadyStarted() {
    game.startGame(this.deck, this.board);
    game.dealCards();
  }

  /**
   * Testing that game throws IAE if playing to invalid index.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToBoardOutOfBounds() {
    game.startGame(this.deck, this.board);
    game.playToBoard(-10, 100, 0);
  }

  /**
   * Testing that game throws ISE if it tries to start battle before game has started.
   */
  @Test(expected = IllegalStateException.class)
  public void testStartBattleGameNotStarted() {
    game.startBattle(0, 0);
  }

  /**
   * Testing that game throws ISE if it checks if game is over before game has started.
   */
  @Test(expected = IllegalStateException.class)
  public void testIsGameOverGameNotStarted() {
    game.isGameOver();
  }

  /**
   * Testing that game throws ISE if it checks for winner before game has started.
   */
  @Test(expected = IllegalStateException.class)
  public void testGetWinnerGameNotOver() {
    game.startGame(this.deck, this.board);
    game.getWinner();
  }

  /**
   * Testing that game deals cards evenly.
   */
  @Test
  public void testEvenDeal() {
    game.dealCards();
    assertEquals(game.getPlayerOneHand().size(), game.getPlayerTwoHand().size());
  }

  /**
   * Testing that game deals (N+1)/2 where N is the number of tiles on the board.
   */
  @Test
  public void testDealHalf() throws FileNotFoundException {
    game.dealCards();
    assertEquals(game.getPlayerOneHand().size(), (game.getNumTiles() + 1) / 2);
  }

  /**
   * Testing that model throws IAE if playing to a hole.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayToHole() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(1, 1, 0);
  }

  /**
   * Testing that model throws IAE if playing invalid hand index.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayOutOfRangeHand() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(0, 0, 1000);
  }

  /**
   * Testing that model throws IAE if playing invalid board index.
   */
  @Test(expected = IllegalArgumentException.class)
  public void testPlayOutOfRangeBoard() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(1000, 0, 0);
  }

  /**
   * Tests that cards are properly flipped.
   */
  @Test
  public void testCardFlip() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(0, 0, 0);
    game.playToBoard(1, 0, 2);
    assertEquals(game.getBoard()[0][0].getColor(), game.getBoard()[1][0].getColor());
  }

  /**
   * Tests cards are properly flipped and the combo effect works.
   */
  @Test
  public void testComboFlip() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(0, 0, 0);
    game.playToBoard(1, 0, 2);
    game.playToBoard(2, 0, 1);
    //make sure it flips in a line
    assertEquals(game.getBoard()[0][0].getColor(), game.getBoard()[2][0].getColor());
  }

  /**
   * Test get turn works as expected.
   */
  @Test
  public void testGetTurn() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    Assert.assertEquals(game.getTurn(), true);
  }

  /**
   * Tests deck is created properly.
   */
  @Test
  public void testCreateDeck() {
    try {
      Assert.assertEquals(game.createDeck().size(), 20);
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
  }

  /**
   * Tests player hand is created properly.
   */
  @Test
  public void testGetPlayerHand() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    Assert.assertEquals(game.getPlayerHand().size(), (game.getNumTiles() + 1) / 2);
  }

  /**
   * Tests getBoard works as expected.
   */
  @Test
  public void testGetBoard() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    Assert.assertEquals(game.getBoard().length, 5);
    Assert.assertEquals(game.getBoard()[0].length, 7);
  }

  /**
   * Tests board is created properly.
   */
  @Test
  public void testCreateBoard() {
    try {
      Assert.assertEquals(game.createBoard().length, 5);
      Assert.assertEquals(game.createBoard()[0].length, 7);
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
  }

  /**
   * Tests getNumTiles works as expected.
   */
  @Test
  public void testGetNumTiles() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    Assert.assertEquals(game.getNumTiles(), 15);
  }

  /**
   * Testing getBoard() returns a copy of the board.
   */
  @Test
  public void testImmutableGetBoard() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    ThreeTrioCard[][] board = game.getBoard();
    board[0][0] = new PlayingCard("James", Attack.ONE, Attack.TWO, Attack.THREE, Attack.FOUR);
    Assert.assertNotEquals(game.getBoard()[0][0], board[0][0]);
  }

  /**
   * Tests that getPlayerOneHand returns an immutable copy of the player one hand.
   */
  @Test
  public void testGetPlayerOneHandImmutable() {
    game.dealCards();
    List<ThreeTrioCard> originalHand = game.getPlayerOneHand();
    List<ThreeTrioCard> handCopy = game.getPlayerOneHand();

    // Modify the copy
    handCopy.remove(0);

    // Verify that the original hand remains unchanged
    Assert.assertNotEquals(originalHand.size(), handCopy.size());
    Assert.assertEquals(originalHand.size(), game.getPlayerOneHand().size());
  }

  /**
   * Tests that getPlayerOneHand returns an immutable copy of the player one hand.
   */
  @Test
  public void testGetPlayerTwoHandImmutable() {
    game.dealCards();
    List<ThreeTrioCard> originalHand = game.getPlayerTwoHand();
    List<ThreeTrioCard> handCopy = game.getPlayerTwoHand();

    // Modify the copy
    handCopy.remove(0);

    // Verify that the original hand remains unchanged
    Assert.assertNotEquals(originalHand.size(), handCopy.size());
    Assert.assertEquals(originalHand.size(), game.getPlayerTwoHand().size());
  }

  @Test
  public void testGetCard() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    Assert.assertEquals(game.getCard(0, 0).getName(), game.getBoard()[0][0].getName());
  }

  @Test
  public void testGetCardIsImmutable() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(0, 0, 0);
    ThreeTrioCard card = game.getCard(0, 0);
    card.setColor(Color.BLUE);
    Assert.assertNotEquals(game.getCard(0, 0).getColor(), Color.BLUE);
  }

  @Test
  public void testGetCardColor() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    game.playToBoard(0, 0, 0);
    Assert.assertEquals(game.getCardColor(0, 0), Color.RED);
  }

  @Test
  public void testIsValidMove() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    // Asserts true because the card is played to a playable spot
    Assert.assertTrue(game.isValidMove(0, 0));
    game.playToBoard(0, 0, 0);
    // Asserts false because there is already a card where this card is trying to be played
    Assert.assertFalse(game.isValidMove(0, 0));
    // Asserts false because we are trying to play to a hole
    Assert.assertFalse(game.isValidMove(1, 1));
    // Asserts false because we are trying to play to a spot that is out of bounds
    Assert.assertFalse(game.isValidMove(1000, 1000));
  }

  @Test
  public void testGetScore() {
    try {
      game.startGame(game.createDeck(), game.createBoard());
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    // Check before any cards are played the score is the # of cards in both players hands
    Assert.assertEquals(game.getScore(Color.RED), game.getPlayerOneHand().size());
    Assert.assertEquals(game.getScore(Color.BLUE), game.getPlayerTwoHand().size());
    // Check score increases when placing a card to the board for both players,
    // and then the game will refresh their hands
    game.playToBoard(0, 0, 0);
    // Play to the board so blue flips red
    game.playToBoard(0, 1, 0);
    // Check that red went down a card
    Assert.assertEquals(game.getScore(Color.RED), 7);
    // Check that blue went up a card
    Assert.assertEquals(game.getScore(Color.BLUE), 9);
  }

}
