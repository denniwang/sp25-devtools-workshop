## Overview

This codebase is designed to implement a card game called "ThreeTrioGame". The game involves
creating a board and a deck of cards from configuration files, and players take turns to play the
game until a winner is determined. The codebase assumes that users have a basic understanding of
Java programming and familiarity with concepts like file I/O, collections, and object-oriented
programming. The codebase is designed to be extensible, allowing for modifications to the game
rules, card properties, and board configurations.

## Quick start

1. Direct yourself to the test directory to run the program.
2. Setup the model and view
   - game = new ThreeTrioGame("board.config", "deck.config");
   - this.deck = game.createDeck();
   - this.board = game.createBoard();
   - game.setBoard(this.board);
   - game.setDeck(this.deck);
   - view = new GameView(game);
3. Play the game to your liking
   - try { <br>
     &nbsp;&nbsp;&nbsp;&nbsp;game.startGame(game.createDeck(), game.createBoard()); <br>
     } catch (FileNotFoundException e) { <br>
     &nbsp;&nbsp;&nbsp;&nbsp;e.printStackTrace(); <br>
     }
   - game.playToBoard(0,0,0); <br>
     game.playToBoard(0,1,0); <br>
     whatever other commands you want...
   - game.isGameOver(); <br>
     game.getWinner(); <br>
     whatever else you would want to see

## Key Components

- **ThreeTrioGame**: This is the main class that drives the control flow of the game. It handles the creation of the deck and board, manages the game state, and determines the winner.
- **ThreeTrioCard**: Represents a card in the game. Each card has a name, attack values for four directions, and a color.
- **ConfigReader**: Responsible for reading the configuration files (`deck.config` and `board.config`) and creating the deck and board based on the configurations.

## Key Subcomponents

### ThreeTrioGame
- `createDeck()`: Reads the `deck.config` file and creates a list of `ThreeTrioCard` objects.
- `createBoard()`: Reads the `board.config` file and creates a 2D array of `ThreeTrioCard` objects.
- `isGameOver()`: Checks if the game is over by verifying if all cards have been played.
- `getWinner()`: Determines the winner based on the scores of the players.
- `boardToString()`, `deckToString()`, `handToString()`: Utility methods to convert the board, deck, and hand to string representations.

### ThreeTrioCard
- `ThreeTrioCard(String name, Attack north, Attack south, Attack east, Attack west)`: Constructor to initialize a card with a name and attack values.
- `isHole()`: Checks if the card is a hole.
- `getColor()`: Returns the color of the card.
- `shortString()`, `toString()`: Utility methods to convert the card to string representations.

### ConfigReader
- `createDeck()`: Reads the `deck.config` file and creates a list of `ThreeTrioCard` objects.
- `createBoard()`: Reads the `board.config` file and creates a 2D array of `ThreeTrioCard` objects.

### Source Organization

#### Directories and Components

- **src/main/java/model**: Contains the core game logic and data structures.
    - `ThreeTrioGame.java`: Main class that drives the control flow of the game.
    - `ThreeTrioCard.java`: Represents a card in the game.
    - `ConfigReader.java`: Responsible for reading the configuration files and creating the deck and board.

- **src/main/java/view**: Contains the classes related to the game's user interface.
    - `GameView.java`: Handles the display of the game state.

- **src/test/java**: Contains the test cases for the game.
    - `ModelTests.java`: Tests for the core game logic in `ThreeTrioGame`.
