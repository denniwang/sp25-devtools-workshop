package view;

import model.ThreeTrioCard;
import model.ThreeTrioGame;


/**
 * Class to be the view of Three Trio.
 */
public class GameView implements ThreeTrioView {
  private ThreeTrioGame model;

  /**
   * Constructor for the game view.
   *
   * @param model the model of the game
   */
  public GameView(ThreeTrioGame model) {
    this.model = model;
  }

  private String boardToString() {
    StringBuilder sb = new StringBuilder();
    int rowIdx = 0;
    for (ThreeTrioCard[] row : model.getBoard()) {
      for (ThreeTrioCard card : row) {
        sb.append(card.shortString());
      }
      if (rowIdx++ < model.getBoard().length - 1) {
        sb.append("\n");
      }
    }
    return sb.toString();
  }

  private String handToString() {
    StringBuilder sb = new StringBuilder();
    int cardIdx = 0;
    for (ThreeTrioCard card : model.getPlayerHand()) {
      sb.append(card.toString());
      if (cardIdx++ < model.getPlayerHand().size() - 1) {
        sb.append(System.lineSeparator());
      }
    }
    return sb.toString();
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Player: " + (model.getTurn() ? "Player 1" : "Player 2"));
    sb.append(System.lineSeparator());
    sb.append(boardToString());
    sb.append(System.lineSeparator());
    sb.append("Hand:");
    sb.append(System.lineSeparator());
    sb.append(handToString());
    return sb.toString();
  }
}
