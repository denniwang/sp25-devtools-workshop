package model;

import java.util.HashMap;

/**
 * Class to represent a playing card in the game.
 */
public class PlayingCard implements ThreeTrioCard {
  private String name;
  private HashMap<Direction, Attack> attacks;
  private Color color;
  private boolean isHole;

  /**
   * Constructor for a playing card.
   *
   * @param name  the name of the card
   * @param north the attack value of the card in the north direction
   * @param south the attack value of the card in the south direction
   * @param east  the attack value of the card in the east direction
   * @param west  the attack value of the card in the west direction
   */
  public PlayingCard(String name, Attack north, Attack south, Attack east, Attack west) {
    this.attacks = new HashMap<>();
    this.name = name;
    this.attacks.put(Direction.NORTH, north);
    this.attacks.put(Direction.SOUTH, south);
    this.attacks.put(Direction.EAST, east);
    this.attacks.put(Direction.WEST, west);
    this.color = null;
    this.isHole = false;
  }

  /**
   * Constructor for a hole card.
   *
   * @param isHole whether the card is a hole card
   */
  public PlayingCard(boolean isHole) {
    this.isHole = isHole;
    this.name = null;
  }

  /**
   * Constructor for dummy card to represent a tile that is not a playing card.
   */
  public PlayingCard() {
    this.isHole = false;
    this.name = null;
  }

  /**
   * Returns the playing card formatted as a single character string for the board.
   */
  public String shortString() {
    if (this.isHole) {
      return "X";
    } else if (this.name == null) {
      return "_";
    } else {
      return color.toString();
    }
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append(this.name + " ");
    sb.append(attacks.get(Direction.NORTH).getValue() + " ");
    sb.append(attacks.get(Direction.SOUTH).getValue() + " ");
    sb.append(attacks.get(Direction.EAST).getValue() + " ");
    sb.append(attacks.get(Direction.WEST).getValue());
    return sb.toString();
  }

  /**
   * Returns the name of this card.
   */
  public String getName() {
    return this.name;
  }

  /**
   * Returns whether this card is a hole card.
   */
  public boolean isHole() {
    return this.isHole;
  }

  /**
   * Returns the color of this card.
   */
  public Color getColor() {
    return this.color;
  }

  /**
   * Sets the color of this card.
   */
  public void setColor(Color color) {
    this.color = color;
  }

  public HashMap<Direction, Attack> getAttacks() {
    return this.attacks;
  }
}
