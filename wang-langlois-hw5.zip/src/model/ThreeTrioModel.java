package model;

import java.io.FileNotFoundException;
import java.util.List;

/**
 * Interface for the Three Trio game model.
 */
public interface ThreeTrioModel<C extends ThreeTrioCard> {
  /**
   * Start the game of Three Trio.
   *
   * @param deck  the deck of cards to use for the game
   * @param board the board to use for the game
   * @throws IllegalArgumentException if the deck is not large enough to start the game
   * @throws IllegalStateException    if the game has already started or is already over
   * @throws IllegalArgumentException if the deck or board are null
   * @throws IllegalArgumentException if the board is not the correct size
   * @throws IllegalArgumentException if the board contains any null elements
   */
  void startGame(List<ThreeTrioCard> deck, ThreeTrioCard[][] board);

  /**
   * Play a card to the board.
   *
   * @param row     the row to play the card to
   * @param col     the column to play the card to
   * @param handIdx the index of the card in the player's hand
   * @throws IllegalArgumentException if the row or column are out of bounds
   * @throws IllegalArgumentException if the card is not played to a tile
   */
  void playToBoard(int row, int col, int handIdx);

  /**
   * Create the deck of cards for the game.
   *
   * @throws FileNotFoundException if the deck config file is not found.
   */
  List<C> createDeck() throws FileNotFoundException;

  /**
   * Create the board for the game.
   *
   * @throws FileNotFoundException if the board config file is not found.
   */
  C[][] createBoard() throws FileNotFoundException;

  /**
   * Start a battle between the last card placed and those cards cardinally adjacent to it.
   *
   * @throws IllegalStateException if the game has not started or if the game is over.
   */
  void startBattle(int row, int col);

  /**
   * Returns whether or not the game is over.
   *
   * @throws IllegalStateException if the game has not started.
   */
  boolean isGameOver();

  /**
   * Deal the cards to the players at the start of the game.
   *
   * @throws IllegalStateException if game has already started.
   */
  void dealCards();

  /**
   * Get the winner of the game.
   *
   * @throws IllegalStateException if the game is not over.
   */
  Color getWinner();

  /**
   * Iterates through the board and returns the number of tiles.
   *
   * @return the number of tiles on the board.
   */
  int getNumTiles();

  /**
   * Returns the hand of the current player.
   *
   * @return hand of current player as a List of TTCard
   */
  List<ThreeTrioCard> getPlayerHand();

  /**
   * Returns the board of the game as a 2D array of TTCards.
   *
   * @return a 2d array of ThreeTruoCards representing the board.
   */
  ThreeTrioCard[][] getBoard();

  /**
   * Returns the current player's turn.
   *
   * @return the player whose turn it is.
   */
  boolean getTurn();
}
