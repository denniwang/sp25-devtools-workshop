package model;

/**
 * Enum to represent the direction of a card.
 */
public enum Direction {
  NORTH, SOUTH, EAST, WEST
}
