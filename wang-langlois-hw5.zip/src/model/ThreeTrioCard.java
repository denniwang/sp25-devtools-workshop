package model;


import java.util.HashMap;

/**
 * Interface to represent a playing card in the game.
 */
public interface ThreeTrioCard {
  /**
   * Returns the playing card formatted as a single character string for the board.
   */
  String shortString();

  /**
   * Returns the playing card formatted including its name and attack values.
   */
  String toString();

  /**
   * Returns the name of this card.
   */
  String getName();

  /**
   * Returns whether this card is a hole card.
   */
  boolean isHole();

  /**
   * Returns the color of this card.
   */
  Color getColor();

  /**
   * Sets the color of this card.
   */
  void setColor(Color color);

  /**
   * Returns all attack values for this card.
   */
  HashMap<Direction, Attack> getAttacks();
}
