package model;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Represents a game of Three Trio.
 *
 * @invariant: playerOneTurn cannot be true if playerOne played their last card.
 */
public class ThreeTrioGame implements ThreeTrioModel<ThreeTrioCard> {

  private List<ThreeTrioCard> deck;
  private List<ThreeTrioCard> playerOneHand;
  private List<ThreeTrioCard> playerTwoHand;
  private boolean playerOneTurn;
  private ThreeTrioCard[][] board;
  private ConfigReader configReader;
  private boolean gameStarted;
  private boolean gameOver;

  /**
   * Constructs a new game of Three Trio.
   */
  public ThreeTrioGame() {
    this.deck = new ArrayList<>();
    this.playerOneTurn = true;
    this.playerOneHand = new ArrayList<>();
    this.playerTwoHand = new ArrayList<>();
    this.gameStarted = false;
    this.gameOver = false;
  }

  /**
   * Constructs a new game of Three Trio with the given board and deck configurations.
   *
   * @param boardConfig the path to the board configuration file
   * @param deckConfig  the path to the deck configuration file
   */
  public ThreeTrioGame(String boardConfig, String deckConfig) {
    this.deck = new ArrayList<>();
    this.playerOneTurn = true;
    this.configReader = new ConfigReader(Objects.requireNonNull(boardConfig),
            Objects.requireNonNull(deckConfig));
    this.playerOneHand = new ArrayList<>();
    this.playerTwoHand = new ArrayList<>();
    this.gameStarted = false;
    this.gameOver = false;
  }

  /**
   * Sets this game's deck to the given deck.
   *
   * @param deck the desired deck of card to use in the game
   */
  public void setDeck(List<ThreeTrioCard> deck) {
    this.deck = deck;
  }

  /**
   * Sets this game's player one hand to the given hand.
   *
   * @return the player one hand
   */
  public List<ThreeTrioCard> getPlayerOneHand() {

    return new ArrayList<>(playerOneHand);
  }

  /**
   * Sets this game's player two hand to the given hand.
   *
   * @return the player two hand
   */
  public List<ThreeTrioCard> getPlayerTwoHand() {
    return new ArrayList<>(playerTwoHand);
  }

  /**
   * Sets this game's player one turn to the given turn.
   *
   * @param deck  the deck of cards to use for the game
   * @param board the board to use for the game
   */
  @Override
  public void startGame(List<ThreeTrioCard> deck, ThreeTrioCard[][] board) {
    if (deck == null || board == null) {
      throw new IllegalArgumentException("The deck and board must not be null");
    }
    for (ThreeTrioCard[] row : board) {
      for (ThreeTrioCard card : row) {
        if (card == null) {
          throw new IllegalArgumentException("The board must not contain any null elements");
        }
      }
    }
    if (board.length % 2 == 0 || board[0].length % 2 == 0) {
      throw new IllegalArgumentException("The board must have odd number of tiles");
    }
    this.board = board;
    if (deck.size() < getNumTiles() + 1) {
      throw new IllegalArgumentException("There must be enough cards to start the game, deck size:"
              + deck.size() + " numTiles: " + getNumTiles());
    }
    if (this.gameStarted || this.gameOver) {
      throw new IllegalStateException("The game is already started or is already over");
    }
    List<ThreeTrioCard> deckCopy = new ArrayList<>();
    for (ThreeTrioCard card : deck) {
      deckCopy.add(card);
    }
    this.deck = deckCopy;
    // Collections.shuffle(this.deck);
    this.dealCards();
    this.gameStarted = true;
  }

  /**
   * Deals the cards to the players.
   */
  @Override
  public void dealCards() {
    if (this.gameStarted) {
      throw new IllegalStateException("The game has already started");
    }
    int count = 0;
    for (ThreeTrioCard curCard : deck) {
      if (count % 2 == 0) {
        curCard.setColor(Color.RED);
        playerOneHand.add(curCard);
      } else {
        curCard.setColor(Color.BLUE);
        playerTwoHand.add(curCard);
      }
      count++;
      // make sure to not over deal cards.
      if (count == getNumTiles() + 1) {
        return;
      }
    }
  }

  /**
   * Plays a card from the player's hand to the board.
   *
   * @param row     the row to play the card to
   * @param col     the column to play the card to
   * @param handIdx the index of the card in the player's hand
   */
  @Override
  public void playToBoard(int row, int col, int handIdx) {
    if (row < 0 || row >= board.length || col < 0 || col >= board[0].length) {
      throw new IllegalArgumentException("Invalid row or column");
    }
    if (board[row][col].isHole()) {
      throw new IllegalArgumentException("Must play to a tile");
    }

    if (this.playerOneTurn) {
      this.board[row][col] = playerOneHand.remove(handIdx);
      this.playerOneTurn = false;
    } else {
      this.board[row][col] = playerTwoHand.remove(handIdx);
      this.playerOneTurn = true;
    }
    this.startBattle(row, col);
  }

  /**
   * Flips adjacent cards to the given card and handles combo.
   *
   * @param row the row of the card
   * @param col the column of the card
   */
  @Override
  public void startBattle(int row, int col) {
    if (!this.gameStarted | this.gameOver) {
      throw new IllegalStateException("The game is not started or is already over");
    }
    ThreeTrioCard lastCard = board[row][col];
    List<ThreeTrioCard> flippedCards = new ArrayList<>();
    this.flipAdjacentCards(row, col, lastCard, flippedCards);
  }

  /**
   * Flips adjacent cards to the given card and handles combo.
   *
   * @param row          the row of the card
   * @param col          the column of the card
   * @param lastCard     the last card flipped
   * @param flippedCards the list of flipped cards
   */
  private void flipAdjacentCards(int row, int col, ThreeTrioCard lastCard,
                                 List<ThreeTrioCard> flippedCards) {
    // Check NORTH
    checkAndFlip(row - 1, col, Direction.NORTH, Direction.SOUTH, row, col, lastCard, flippedCards);
    // Check SOUTH
    checkAndFlip(row + 1, col, Direction.SOUTH, Direction.NORTH, row, col, lastCard, flippedCards);
    // Check WEST
    checkAndFlip(row, col - 1, Direction.WEST, Direction.EAST, row, col, lastCard, flippedCards);
    // Check EAST
    checkAndFlip(row, col + 1, Direction.EAST, Direction.WEST, row, col, lastCard, flippedCards);
  }

  /**
   * Flips adjacent cards to the given card and handles combo.
   *
   * @param row          the row of the card
   * @param col          the column of the card
   * @param lastCard     the last card flipped
   * @param flippedCards the list of flipped cards
   * @param lastDir      the last direction flipped
   */
  private void recursivelyFlip(int row, int col, ThreeTrioCard lastCard,
                               List<ThreeTrioCard> flippedCards, Direction lastDir) {
    // Check NORTH
    if (lastDir != Direction.NORTH) {
      checkAndFlip(row - 1, col, Direction.NORTH,
              Direction.SOUTH, row, col, lastCard, flippedCards);
    }
    // Check SOUTH
    if (lastDir != Direction.SOUTH) {
      checkAndFlip(row + 1, col, Direction.SOUTH,
              Direction.NORTH, row, col, lastCard, flippedCards);
    }
    // Check WEST
    if (lastDir != Direction.WEST) {
      checkAndFlip(row, col - 1, Direction.WEST,
              Direction.EAST, row, col, lastCard, flippedCards);
    }
    // Check EAST
    if (lastDir != Direction.EAST) {
      checkAndFlip(row, col + 1, Direction.EAST,
              Direction.WEST, row, col, lastCard, flippedCards);
    }
  }

  /**
   * Recursively flips an adjacent card if it meets the conditions.
   *
   * @param adjRow       the adjacent row
   * @param adjCol       the adjacent column
   * @param dirFrom      the direction from which the card is being flipped
   * @param dirTo        the direction to which the card is being flipped
   * @param row          the row of the card
   * @param col          the column of the card
   * @param lastCard     the last card flipped
   * @param flippedCards the list of flipped cards
   */
  private void checkAndFlip(int adjRow, int adjCol, Direction dirFrom, Direction dirTo, int row,
                            int col, ThreeTrioCard lastCard, List<ThreeTrioCard> flippedCards) {
    // Ensure the adjacent row and col are within bounds
    if (adjRow >= 0 && adjRow < board.length && adjCol >= 0 && adjCol < board[0].length) {
      ThreeTrioCard adjacentCard = board[adjRow][adjCol];

      // Check conditions for flipping the card
      if (adjacentCard.getColor() != lastCard.getColor()
              && !adjacentCard.isHole()
              && adjacentCard.getName() != null
              && lastCard.getAttacks().get(dirFrom).getValue()
              > adjacentCard.getAttacks().get(dirTo).getValue()) {
        flippedCards.add(adjacentCard);
        adjacentCard.setColor(lastCard.getColor());
        // recursively flip from this card we just flipped
        // note we pass the dirTo because to the new card, that is the direction we are coming from
        recursivelyFlip(adjRow, adjCol, adjacentCard, flippedCards, dirTo);
      }
    }
  }

  /**
   * Determines if the game is over.
   *
   * @return whether the game is over
   */
  @Override
  public boolean isGameOver() {
    if (!this.gameStarted) {
      throw new IllegalStateException("The game has not started yet");
    }
    for (ThreeTrioCard[] row : board) {
      for (ThreeTrioCard card : row) {
        if (!card.isHole() && card.getName() == null) {
          return false;
        }
      }
    }
    this.gameOver = true;
    return true;
  }

  /**
   * Determines the winner of the game.
   *
   * @return the color of the winner
   */
  @Override
  public Color getWinner() {
    if (!this.gameStarted || !this.gameOver) {
      throw new IllegalStateException("The game is not finished or started");
    }
    int redScore = 0;
    int blueScore = 0;
    for (ThreeTrioCard[] row : board) {
      for (ThreeTrioCard card : row) {
        if (card.getColor() == Color.RED) {
          redScore++;
        } else if (card.getColor() == Color.BLUE) {
          blueScore++;
        }
      }
    }
    redScore += this.playerOneHand.size();
    blueScore += this.playerTwoHand.size();
    if (redScore > blueScore) {
      return Color.RED;
    } else if (blueScore > redScore) {
      return Color.BLUE;
    } else {
      return null; // figure out what to actually put here in the case of a tie bc idk
    }
  }

  /**
   * Creates a deck of cards from the configuration file.
   *
   * @return a list of all the cards in the deck
   * @throws FileNotFoundException if the file is not found
   */
  @Override
  public List<ThreeTrioCard> createDeck() throws FileNotFoundException {
    try {
      return configReader.createDeck();
    } catch (NullPointerException e) {
      throw new IllegalArgumentException("Deck config path not given");
    }
  }

  /**
   * Creates the board from the configuration file.
   *
   * @return a 2D array of cards representing the board
   * @throws FileNotFoundException if the file is not found
   */
  @Override
  public ThreeTrioCard[][] createBoard() throws FileNotFoundException {
    try {
      return configReader.createBoard();
    } catch (NullPointerException e) {
      throw new IllegalArgumentException("Board config path not given");
    }
  }

  /**
   * Returns the number of tiles on the board.
   *
   * @return the number of tiles on the board
   */
  @Override
  public int getNumTiles() {
    int numTiles = 0;
    for (int row = 0; row < board.length; row++) {
      for (int col = 0; col < board[row].length; col++) {
        if (!board[row][col].isHole()) {
          numTiles++;
        }
      }
    }
    return numTiles;
  }

  /**
   * Returns the player's hand.
   *
   * @return the player's hand
   */
  @Override
  public List<ThreeTrioCard> getPlayerHand() {
    if (this.playerOneTurn) {
      return this.playerOneHand;
    } else {
      return this.playerTwoHand;
    }
  }

  /**
   * Returns a new copy of this board.
   *
   * @return the board
   */
  @Override
  public ThreeTrioCard[][] getBoard() {
    if (this.board == null) {
      return null;
    }
    ThreeTrioCard[][] boardCopy = new ThreeTrioCard[this.board.length][this.board[0].length];
    for (int i = 0; i < this.board.length; i++) {
      for (int j = 0; j < this.board[i].length; j++) {
        // Assuming ThreeTrioCard is immutable or has a proper copy constructor
        boardCopy[i][j] = this.board[i][j];
      }
    }
    return boardCopy;
  }

  /**
   * Sets the board to the given board.
   *
   * @param board the board to set
   */
  public void setBoard(ThreeTrioCard[][] board) {
    this.board = board;
  }

  /**
   * Returns the current turn.
   *
   * @return the current turn
   */
  @Override
  public boolean getTurn() {
    return this.playerOneTurn;
  }
}

