package provider;

/**
 * An enum created for the two different kinds of cells in the grind.
 */
public enum CellType {
    HOLE,
    CARD_CELL
}
